# Sistema de Gestión Académica y Soporte TI - CUN

Proyecto integrador desarrollado para la asignatura de **Programación Orientada a Objetos (POO)** en la Corporación Unificada Nacional de Educación Superior (CUN).

## 📌 Descripción del Proyecto
El sistema permite automatizar la atención de solicitudes técnicas (tickets de soporte TI) y la gestión de datos académicos de estudiantes de la CUN, integrando arquitectura POO en Python con persistencia relacional SQLite.

## 🚀 Pilares POO e Integración Aplicados
- **Encapsulamiento:** El atributo `_promedio` en la clase `Estudiante` se define como privado y se controla a través del método `actualizar_promedio()`.
- **Manejo de Excepciones:** Se emplean bloques `try-except` para interceptar notas fuera del rango permitido (0.0 a 5.0) mediante `ValueError`, evitando caídas del sistema.
- **Composición:** La clase `TicketSoporte` recibe un objeto de tipo `Estudiante`, estableciendo una fuerte relación entre la solicitud de soporte y el usuario emisor.
- **Persistencia en Base de Datos (SQLite):** El módulo `database.py` crea la base de datos `cun_sistema.db` con tablas `estudiantes` y `tickets_soporte` vinculadas por clave foránea.

## 📁 Estructura del Repositorio
```text
proyecto_poo_cun/
├── database.py       # Script de creación e inicialización de SQLite
├── main.py           # Clases POO (Estudiante, TicketSoporte) y menú de pruebas
└── README.md         # Documentación oficial del repositorio
```

## 💻 Instrucciones de Ejecución
1. Clonar el repositorio:
   ```bash
   git clone https://github.com/TU_USUARIO/proyecto_poo_cun.git
   ```
2. Navegar al directorio del proyecto:
   ```bash
   cd proyecto_poo_cun
   ```
3. Ejecutar la aplicación principal:
   ```bash
   python main.py
   ```
