import sqlite3

def crear_base_datos_cun():
    """
    Crea e inicializa la base de datos relacional SQLite 'cun_sistema.db'
    con las tablas 'estudiantes' y 'tickets_soporte' solicitadas por la CUN.
    """
    try:
        conn = sqlite3.connect('cun_sistema.db')
        cursor = conn.cursor()

        # Tabla Estudiantes
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS estudiantes (
                id_estudiante TEXT PRIMARY KEY,
                nombre TEXT NOT NULL,
                programa TEXT NOT NULL,
                promedio REAL DEFAULT 0.0
            )
        ''')

        # Tabla Tickets de Soporte TI (con Clave Foránea)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tickets_soporte (
                id_ticket INTEGER PRIMARY KEY AUTOINCREMENT,
                id_estudiante TEXT NOT NULL,
                categoria TEXT NOT NULL,
                descripcion TEXT NOT NULL,
                estado TEXT DEFAULT 'ABIERTO',
                FOREIGN KEY (id_estudiante) REFERENCES estudiantes (id_estudiante)
            )
        ''')

        conn.commit()
        conn.close()
        print("[Exitoso] Base de datos cun_sistema.db creada e inicializada correctamente.")
    except sqlite3.Error as e:
        print(f"[Error BD]: {e}")

if __name__ == '__main__':
    crear_base_datos_cun()
