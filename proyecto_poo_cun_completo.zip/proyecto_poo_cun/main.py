import sqlite3
from database import crear_base_datos_cun

class Estudiante:
    """
    Clase que representa a un estudiante de la CUN.
    Aplica Encapsulamiento en el atributo privado _promedio.
    """
    def __init__(self, id_estudiante: str, nombre: str, programa: str, promedio: float = 0.0):
        self.id_estudiante = id_estudiante
        self.nombre = nombre
        self.programa = programa
        self._promedio = 0.0  # Atributo privado
        self.actualizar_promedio(promedio)

    @property
    def promedio(self) -> float:
        return self._promedio

    def actualizar_promedio(self, nuevo_promedio: float):
        """
        Valida y actualiza el promedio del estudiante.
        Utiliza manejo de excepciones con try-except para validar rangos (0.0 - 5.0).
        """
        try:
            if 0.0 <= nuevo_promedio <= 5.0:
                self._promedio = nuevo_promedio
                print(f"[OK] Promedio actualizado a {self._promedio} para {self.nombre}")
            else:
                raise ValueError("El promedio debe estar entre 0.0 y 5.0")
        except ValueError as err:
            print(f"[Error de Validación]: {err}")

    def guardar_en_db(self):
        """Guarda o actualiza la información del estudiante en SQLite."""
        try:
            conn = sqlite3.connect('cun_sistema.db')
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO estudiantes (id_estudiante, nombre, programa, promedio)
                VALUES (?, ?, ?, ?)
            ''', (self.id_estudiante, self.nombre, self.programa, self._promedio))
            conn.commit()
            conn.close()
            print(f"[OK] Estudiante {self.nombre} guardado en la base de datos.")
        except sqlite3.Error as e:
            print(f"[Error BD al guardar estudiante]: {e}")


class TicketSoporte:
    """
    Clase que representa una solicitud de soporte técnico en la CUN.
    Aplica Composición asociando una instancia de la clase Estudiante.
    """
    def __init__(self, estudiante: Estudiante, categoria: str, descripcion: str):
        self.estudiante = estudiante  # Composición / Relación con Estudiante
        self.categoria = categoria
        self.descripcion = descripcion
        self.estado = "ABIERTO"

    def registrar_ticket(self):
        """Registra el ticket en SQLite garantizando que el estudiante existe en la BD."""
        try:
            # Garantizar que el estudiante existe primero en la BD
            self.estudiante.guardar_en_db()

            conn = sqlite3.connect('cun_sistema.db')
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO tickets_soporte (id_estudiante, categoria, descripcion, estado)
                VALUES (?, ?, ?, ?)
            ''', (self.estudiante.id_estudiante, self.categoria, self.descripcion, self.estado))
            conn.commit()
            conn.close()
            print(f"[OK] Ticket registrado exitosamente para {self.estudiante.nombre}.")
        except sqlite3.Error as e:
            print(f"[Error BD al registrar ticket]: {e}")


def consultar_tickets():
    """Realiza un JOIN relacional entre las tablas tickets_soporte y estudiantes."""
    print("\n==========================================")
    print("   CONSULTA DE TICKETS DE SOPORTE CUN")
    print("==========================================")
    try:
        conn = sqlite3.connect('cun_sistema.db')
        cursor = conn.cursor()
        cursor.execute('''
            SELECT t.id_ticket, e.nombre, e.programa, t.categoria, t.descripcion, t.estado
            FROM tickets_soporte t
            JOIN estudiantes e ON t.id_estudiante = e.id_estudiante
        ''')
        registros = cursor.fetchall()
        conn.close()

        if not registros:
            print("No hay tickets registrados actualmente.")
            return

        for reg in registros:
            print(f"• ID Ticket: {reg[0]} | Estudiante: {reg[1]} ({reg[2]})")
            print(f"  Categoría: {reg[3]} | Estado: {reg[5]}")
            print(f"  Detalle: {reg[4]}\n")
    except sqlite3.Error as e:
        print(f"[Error de Consulta BD]: {e}")


if __name__ == '__main__':
    print("--- INICIALIZANDO SISTEMA DE POO Y BD CUN ---")
    
    # 1. Crear base de datos y tablas
    crear_base_datos_cun()

    # 2. Instanciar estudiantes (POO + Encapsulamiento)
    est1 = Estudiante("E-101", "Laura Gómez", "Ingeniería de Sistemas", 4.5)
    est2 = Estudiante("E-102", "Carlos Pérez", "Administración de Empresas", 3.8)

    # Prueba de validación de excepción (fuera de rango)
    print("\n--- PRUEBA DE MANEJO DE EXCEPCIONES ---")
    est1.actualizar_promedio(6.0)

    # 3. Crear y registrar Tickets de Soporte (Composición)
    print("\n--- REGISTRO DE TICKETS ---")
    ticket1 = TicketSoporte(est1, "Plataforma Virtual", "No puedo acceder al aula de POO.")
    ticket1.registrar_ticket()

    ticket2 = TicketSoporte(est2, "Red Wi-Fi", "Problemas de conexión en el bloque B.")
    ticket2.registrar_ticket()

    # 4. Consultar registros en BD
    consultar_tickets()
